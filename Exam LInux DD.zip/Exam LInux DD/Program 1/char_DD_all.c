#include <linux/module.h>
#include <linux/init.h>
#include <linux/kdev_t.h>
#include <linux/types.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/semaphore.h>

#include <linux/rwsem.h> //for read write lock

#include <linux/wait.h>             //for wait queue

struct rw_semaphore *rwsem;   //for read lock



void init_rwsem(struct rw_semaphore rwsem);  //read write semaphore init.



#define NAME MyCharDevice

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rajeev_Sharma");


struct semaphore *sem;   //semaphore 
void sema_init(sem);



void down_write(rwsem);  //write lock

void down_read(rwsem);   //read lock

void down(sem);  //locking_Semaphore


char kbuff[50]="KERNEL BUFFER OF SIZE 50 DECLARED IN READ";  //Declaration globally



void up(sem);   //unlocking_semaphore

void up_read(rwsem);   //read unlock

void up_write(rwsem);  //write unlock









int NAME_open(struct inode *inode , struct file *filp);

int NAME_release(struct inode *inode , struct file *filp);


ssize_t NAME_read(struct file *filp,char __user *Ubuff,size_t count,loff_t *offp);

ssize_t NAME_write(struct file *filp,const char __user *Ubuff,size_t count,loff_t *offp);

struct file_operations fops =
{
	.owner = THIS_MODULE,
	.open  = NAME_open,
	.write = NAME_write,
	.read = NAME_read,	
	.release = NAME_release,

};


struct cdev *my_cdev1;
struct cdev *my_cdev2;


static int CharDevice_init(void)
{
	int result1,result2;
    int MAJOR1,MINOR1;
    int MAJOR2,MINOR2;

	dev_t mydev1;
    dev_t mydev2;

	mydev1 = MKDEV(255,0);
    mydev2 = MKDEV(44,0);
    
    MAJOR1 = MAJOR(mydev1);
	MINOR1 = MINOR(mydev1);

    MAJOR2 = MAJOR(mydev2);
	MINOR2 = MINOR(mydev2);

	printk(KERN_ALERT"\nmajor number of DEVICE 1 is %d  minor number of DEVICE 1 is %d \n",MAJOR1,MINOR1);
    printk(KERN_ALERT"\nmajor number of DEVICE 2 is %d  minor number  of DEVICE 2is %d \n",MAJOR2,MINOR2);
	
	result1 = register_chrdev_region(mydev1,1,"MyCharDevice1");
    result2 = register_chrdev_region(mydev2,1,"MyCharDevice2");
	
	if(result1<0)
	{
		printk(KERN_ALERT"The region is requested for DEVICE 1 is not obtainable\n");
		return (-1);
	}

    if(result2<0)
	{
		printk(KERN_ALERT"The region is requested for DEVICE2 is not obtainable\n");
		return (-1);
	}

	my_cdev1 = cdev_alloc();
	my_cdev2 = cdev_alloc();

    my_cdev1->ops = &fops;
    my_cdev2->ops = &fops;

    

	result1 = cdev_add(my_cdev1,mydev,1);
    result2 = cdev_add(my_cdev2,mydev,1);

	if(result1<0)
	{
		printk(KERN_ALERT"char Device has not been Created....\n");
		unregister_chrdev_region(mydev,1);
		return (-1);
	}

    if(result2<0)
	{
		printk(KERN_ALERT"char Device has not been Created....\n");
		unregister_chrdev_region(mydev,1);
		return (-1);
	}

	return 0;
}


void CharDevice_exit(void)
{
	dev_t mydev1;
    dev_t mydev2;
   
	int MAJOR1,MINOR1;
    int MAJOR2,MINOR2;

	mydev1 = MKDEV(255,0);
    mydev1 = MKDEV(44,0);
    
	MAJOR1 = MAJOR(mydev1);
	MINOR1= MINOR(mydev1);

    MAJOR2 = MAJOR(mydev2);
	MINOR2= MINOR(mydev2);

	printk(KERN_ALERT"the major number of DEVICE 1 %d and minor number DEVICE 2 is %d\n",MAJOR,MINOR);
    printk(KERN_ALERT"the major number of DEVICE 1 %d and minor number DEVICE 2 is %d\n",MAJOR,MINOR);


	unregister_chrdev_region(mydev1,1);
	unregister_chrdev_region(mydev2,1);

	cdev_del(my_cdev1);
	cdev_del(my_cdev2);
	

	printk(KERN_ALERT"I have deleted that have created\n");

}



int NAME_open(struct inode *inode , struct file *filp)
{
	printk(KERN_ALERT"hey Buddy i am Opend file LOL !!!");
	return 0;
}


int NAME_release(struct inode *inode , struct file *filp)
{

	printk(KERN_ALERT"hey Buddy i am Closed file LOL !!!");
	return 0;
}



ssize_t NAME_write(struct file *filp,const char __user *Ubuff,size_t count,loff_t *offp)
{
	
	int result;
	ssize_t retval;
	result = copy_from_user((char*)kbuff,(char*)Ubuff,count);
	if(result==0)
	{
		printk(KERN_ALERT"Message from user : %s\n",kbuff);
		printk(KERN_ALERT"%d bytes of data written succesfully \n",count);
		retval = count;
		return count;
	}
	else
	{
		printk(KERN_ALERT"ERROR writing data\n");
		retval = -EFAULT;
		return retval;
	}
}


ssize_t NAME_read(struct file *filp,char __user *Ubuff,size_t count,loff_t *offp)
{

	//char kbuff[]="KERNEL BUFFER OF SIZE 50 DECLARED IN READ";
	int result;
	ssize_t retval;
	
	result = copy_to_user((char*)Ubuff,(const char *)kbuff,sizeof(kbuff));

	if(result == 0)
	{

		
		printk(KERN_ALERT"copy to user successfull % d data written \n",sizeof(kbuff));
		retval = sizeof(kbuff);
		return count;
	}
	else
	{
		printk(KERN_ALERT"ERROR writting data to user\n");
		retval = -EFAULT;
		return retval;
	}

}


module_init(CharDevice_init);
module_exit(CharDevice_exit);


